<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="css/language.css">
	<script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
	<title>Compiled Compiler</title>
</head>
<body>

	<!------ File------->

	<header id="return"class="logo">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php" ></i>home</a></li>
				<li><a href="lang.php" class="active"></i>language</a></li>
				<li><a href="quiz.php"></i>Quiz</a></li>
				<li><a href="about.php" ></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>

	<div class="wrapper">
	<div class="container">
	<div class="picture-lang">
	<?php

	if (isset($_GET['picture']))
        {
            $a=$_GET['picture'];
          print "<img src=$a>";
        }

	?>
	</div>
	<div class="picture-lang">
		<?php

	if (isset($_GET['lang']))
        {
            $a=$_GET['lang'];
            $b=$_GET['description'];
          
          print "<h1>$a</h1>";
          print "<p>$b</p>";
        }

	?>
	
	</div>
	</div>
	<div class="lagayan-tatlo">
	<div class="menu-three">
		<ul>
			<li><a href="#pc">PC Application Compilers</a></li>
			<li><a href="#Mobile">Android/Ios Application Compilers</a></li>
		</ul>
	</div>
	</div>
	</div>

	<div class="wrap" id="Mobile">
		<h1>Mobile Applications</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.textasticapp.com/iphone.html"><img src="img/ph5.jpg"></a>
				<p>Textastic Code Editor</p>
				<a href="https://www.textasticapp.com/iphone.html"><span class="iconify" data-icon="fa:apple" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://solesignal.com/draftcode/"><img src="img/ph6.jpg"></a>
				<p>DRAFTCODE</p>
				<a href="https://solesignal.com/draftcode/"><span class="iconify" data-icon="fa:apple" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://app.phpwin.org/#/"><img src="img/ph7.jpg"></a>
				<p>PHPwin</p>
				<a href="https://app.phpwin.org/#/"><span class="iconify" data-icon="fa:apple" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href=""><img src="img/ph9.jpg"></a>
				<p>PHP Code Play</p>
				<a href="https://play.google.com/store/apps/details?id=php.code.play&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.sololearn.php&hl=en&gl=US"><img src="img/ph8.jpg"></a>
				<p>Learn PHP</p>
				<a href="https://play.google.com/store/apps/details?id=com.sololearn.php&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333; font-size: 22px; "></span></a>
			</div>
		</div>
	</div>


	<div class="wrap" id="pc">
		<h1>PC Software Compiler</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.jetbrains.com/phpstorm/"><img src="img/ph1.png"></a>
				<p>PHP Storm</p>
			</div>

			<div class="card">
				<a href="https://atom.io/"><img src="img/ph2.jpg"></a>
				<p>Atom IO</p>
			</div>

			<div class="card">
				<a href="https://www.eclipse.org/pdt/"><img src="img/eclipse.png"></a>
				<p>Eclipse</p>
			</div>

			<div class="card">
				<a href="http://www.aptana.com/"><img src="img/ph3.png"></a>
				<p>Aptana Studio 3</p>
			</div>

			<div class="card">
				<a href="https://code.visualstudio.com/"><img src="img/c12.png"></a>
				<p>Visual Studio Code</p>
			</div>
		</div>
	</div>


<a href="#return" class="return"><i class="fas fa-arrow-up"></i></a>


	<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>
</body>
</html>