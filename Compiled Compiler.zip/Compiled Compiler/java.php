<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/language.css">
	<title>Compiled Compiler</title>
</head>
<body>

	<!------java File------->

	<header id="return"class="logo">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php" ></i>home</a></li>
				<li><a href="lang.php" class="active"></i>language</a></li>
				<li><a href="quiz.php"></i>Quiz</a></li>
				<li><a href="about.php"></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>

	<div class="wrapper">
	<div class="container">
	<div class="picture-lang">
	<?php

	if (isset($_GET['picture']))
        {
            $a=$_GET['picture'];
          print "<img src=$a>";
        }

	?>
	</div>
	<div class="picture-lang">
		<?php

	if (isset($_GET['lang']))
        {
            $a=$_GET['lang'];
            $b=$_GET['description'];
          
          print "<h1>$a</h1>";
          print "<p>$b</p>";
        }

	?>
	
	</div>
	</div>
	<div class="lagayan-tatlo">
	<div class="menu-three">
		<ul>
			<li><a href="#online">Online Compilers</a></li>
			<li><a href="#pc">PC Application Compilers</a></li>
			<li><a href="#Mobile">Android Application Compilers</a></li>
		</ul>
	</div>
	</div>
	</div>


	<div class="wrap" id="online">
		<h1>Online Compiler</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.programiz.com/java-programming/online-compiler/"><img src="img/c2.jpeg"></a>
				<p>Programiz</p>
			</div>

			<div class="card">
				<a href="https://www.onlinegdb.com/online_java_compiler"><img src="img/GDB.png"></a>
				<p>OnlineGDB</p>
			</div>

			<div class="card">
				<a href="https://www.tutorialspoint.com/compile_java_online.php"><img src="img/c1.png"></a>
				<p>Tutorialspoint</p>
			</div>

			<div class="card">
				<a href="https://www.codechef.com/ide"><img src="img/c3.jpg"></a>
				<p>CodeChef</p>
			</div>

			<div class="card">
				<a href="https://paiza.io/projects/Ry2WtKMZW11RCe82ipNN2w?language=java"><img src="image/j5.png"></a>
				<p>Paiza.IO</p>
			</div>

			<div class="card">
				<a href="https://www.jdoodle.com/online-java-compiler/"><img src="image/j1.png"></a>
				<p>JDoodle</p>
			</div>
		</div>
	</div>

	<div class="wrap" id="Mobile">
		<h1>Mobile Applications</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.sololearn.java&utm_source=appgrooves&utm_medium=agp_30b15bcfb2f2013893f3d629d536c182_com.sololearn.java_us_others_16443900261222"><img src="image/j8.jpg"></a>
				<p>Learn Java</p>
				<a href="https://play.google.com/store/apps/details?id=com.sololearn.java&utm_source=appgrooves&utm_medium=agp_30b15bcfb2f2013893f3d629d536c182_com.sololearn.java_us_others_16443900261222"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://apps.apple.com/ru/app/code-compiler-programming/id1397424959"><img src="image/j11.jpg"></a>
				<p>CodeSnack IDE</p>
				<a href="https://apps.apple.com/ru/app/code-compiler-programming/id1397424959"><span class="iconify" data-icon="fa:apple" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.jvdroid&hl=en_US&gl=US"><img src="image/j9.jpg"></a>
				<p>Jvdroid - IDE for Java</p>
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.jvdroid&hl=en_US&gl=US"><img src="image/j9.jpg"></a>
				<p>Jvdroid - IDE for Java</p>"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.programiz.learnjava"><img src="image/j10.png"></a>
				<p>EASY CODER : Learn Java Programming</p>
				<a href="https://play.google.com/store/apps/details?id=com.programiz.learnjava"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.java.malik.javaanim&utm_source=appgrooves&utm_medium=agp_30b15bcfb2f2013893f3d629d536c182_com.java.malik.javaanim_us_others_16443898857766"><img src="image/j2.jpeg"></a>
				<p>Programiz</p>
				<a href="https://play.google.com/store/apps/details?id=com.java.malik.javaanim&utm_source=appgrooves&utm_medium=agp_30b15bcfb2f2013893f3d629d536c182_com.java.malik.javaanim_us_others_16443898857766"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.java.malik.javaanim&utm_source=appgrooves&utm_medium=agp_30b15bcfb2f2013893f3d629d536c182_com.java.malik.javaanim_us_others_16443898857766"><img src="image/j6.png"></a>
				<p>Learn Java Programming</p>
				<a href="https://play.google.com/store/apps/details?id=com.java.malik.javaanim&utm_source=appgrooves&utm_medium=agp_30b15bcfb2f2013893f3d629d536c182_com.java.malik.javaanim_us_others_16443898857766"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>
		</div>
	</div>


	<div class="wrap" id="pc">
		<h1>PC Software Compiler</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.oracle.com/application-development/technologies/jdeveloper.html"><img src="image/j16.png"></a>
				<p>JDoodle</p>
			</div>

			<div class="card">
				<a href="https://www.jetbrains.com/idea/"><img src="image/j13.png"></a>
				<p>IntelliJ IDEA</p>
			</div>

			<div class="card">
				<a href="https://www.eclipse.org/downloads/"><img src="img/eclipse.png"></a>
				<p>Eclipse</p>
			</div>

			<div class="card">
				<a href="https://www.jetbrains.com/idea/"><img src="image/j14.png"></a>
				<p>BlueJ</p>
			</div>

			<div class="card">
				<a href="https://netbeans.org/"><img src="img/net.png"></a>
				<p>Apache NetBeans</p>
			</div>
		</div>
	</div>


<a href="#return" class="return"><i class="fas fa-arrow-up"></i></a>


	<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>
</body>
</html>