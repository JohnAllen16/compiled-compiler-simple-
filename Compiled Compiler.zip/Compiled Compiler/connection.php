<?php
$conn= new mysqli('localhost', 'root', '','cc_db') or die ("DB is not connected");
$query = "SELECT * FROM questions where question_id ORDER BY RAND() LIMIT 5";
$results = $conn->query($query) or die ($conn->error.__LINE__);
$total = $results->num_rows;

while($rows=$results->fetch_assoc())
	{
		$ids = $rows['question_id'];
	}    

?>
