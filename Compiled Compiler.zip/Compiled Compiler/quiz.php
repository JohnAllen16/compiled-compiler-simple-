 <?php include 'connection.php';
       include 'header.php';
?>
<html>
<style type="text/css">
*,
*::before,
*::after{
	box-sizing: border-box;
}

.container2{
	width: 100%;
	height: 70vh;
	padding-top: 4em;
	padding-left: 1em;
	padding-right: 1em;
	display: flex;
	flex-direction: column;
}

.container2 h2{
	padding-bottom: 1em;
}

form{
	width: 100%;
	text-align: center;
}

@media screen and (min-width: 800px){
	.container2{
		max-width: 900px;
		height: 95vh;
		margin: auto;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.submit{
		color: #000;
		background: #fff;
		padding: 5px;
		height: 23px;
		border-radius: 5px;
		border: 1px solid #333;
		font-family: 'Special Elite', cursive;
		transition: 300ms ease-in-out;
		cursor: pointer;
		}

	.submit:hover{
		color: #fff;
		background: #333;
		transition: 300ms ease-in-out;
	}

}

</style>
<!DOCTYPE html>
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <div id="container2">
      <div class="container2">
        <h2>Programming Random Quiz</h2>
	<p>This is a multiple choice quiz to test your knowledge about programming</p>
	<ul>
		<li><strong>Number of Questions: </strong><?php echo $total; ?></ul>
	</ul>
	<form action="" method="GET">
		<input type="text" name="name" placeholder="Enter your Name">
		<input class="submit" type="submit" name="submitbtn"/>

	</form>
      </div>
    </div>
  </body>
</html>
<?php
include 'footer.php'
?>
<?php
	if(isset($_GET['submitbtn'])){
		$name = $_GET['name'];
		header("Location: question.php?n=1&name=".$name."&id=".$ids);		
	}

?>
