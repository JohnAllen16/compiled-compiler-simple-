<?php include "connection.php";?>
<html>
<?php
$select = "SELECT * FROM 'scores' ORDER BY 'score' DESC"
$result = mysqli_query($conn,$select);
$ranking = 1;
////while($row = mysqli_fetch_array($select))
//  {
//  echo $row['name'] . " " . $row['score']; //these are the fields that you have stored in your database table employee
//  echo "<br />";
//  }
//


//while ($row = mysqli_fetch_array($select)) {
//    echo "<td>{$ranking}</td>
//    <td>{$row['name']}</td>
//    <td>{$row['score']}</td>";
//    $ranking++;
}
?>
 <?php if ($result->num_rows > 0): ?>
                <?php while($array=mysqli_fetch_row($result)): ?>
                <tr>
                    <th scope="row"><?php echo $array['name'];?></th>
                    <td><?php echo $array['score'];?></td>
                </tr>
                <?php endwhile; ?>
                <?php else: ?>
                <tr>
                   <td colspan="3" rowspan="1" headers="">No Data Found</td>
                </tr>
                <?php endif; ?>
                <?php mysqli_free_result($result); ?>
</html>
