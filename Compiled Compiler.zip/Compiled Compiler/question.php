<?php include "connection.php";  
	  include 'header.php';
?>
<style>
</style>
<?php session_start(); ?>
<?php
	//Set question number
	$number = (int)$_GET['n'];
	$name = $_GET['name'];
	$id = $_GET['id'];
	// Get Question
	$query = "select * from `questions` where question_id = $id";

	//Get result
	$result = $conn->query($query) or die($conn->error.__LINE__);
	$question = $result->fetch_assoc();


	// Get answers
	$query = "select * from `answers` where question_id = $id";

	//Get results
	$answers = $conn->query($query) or die($conn->error.__LINE__);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <?phpinclude 'header.php'?>
	<link rel="stylesheet" type="text/css" href="css/quiz.css">
  </head>
  <body>
    
  <div id="container2">
 	<div class="container2">
	<form method="post" action="process.php">
	<div class="outof"><p># <?php echo $number;?> of <?php echo $total;?></p></div> 
	<div>Hi! <?php echo $name;?> heres your question:<br></div>
	<br>
	<p class="question">
	   <?php echo $question['question']; ?>
	</p>
	<div class="answers">
	    <?php while($row=$answers->fetch_assoc()): ?>
		<label class="ans"><?php echo $row['answer'];?>
			<input name="answer" type="radio" value="<?php echo $row['id']; ?>"/>
			<span class="checkmark"></span>
        </label>
		<?php endwhile; ?>
	<div>
	      <input class="submit" type="submit" value="submit" />
		  <input type="hidden" name="number" value="<?php echo $number;?>"/>
	      <input type="hidden" name="name" value="<?php echo $name; ?>" />
		  <input type="hidden" name="question_id" value="<?php echo $id; ?>" />
		  </div>
		</div>
		</div>
	</form>
      </div>
    </div>
  </body>
</html>
<?php
include 'footer.php'
?>