<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/language.css">
<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>