-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2022 at 07:06 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `correct` int(11) NOT NULL,
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answers`
--

INSERT INTO `answers` (`id`, `question_id`, `correct`, `answer`) VALUES
(19, 1485234833, 0, 'Philippine Peso'),
(20, 1485234833, 1, 'PHP: Hypertext Preprocessor'),
(21, 1485234833, 0, 'Private Home Page'),
(22, 1442552597, 1, '<?php…?>'),
(23, 1442552597, 0, '<&>...</&>'),
(24, 1442552597, 0, '<?php>...</?>'),
(25, 1442552597, 0, '<script>...</script>'),
(26, 1897737642, 0, '!'),
(27, 1897737642, 0, '&'),
(28, 1897737642, 1, '$'),
(29, 929762612, 0, '</php>'),
(30, 929762612, 0, 'New line'),
(31, 929762612, 1, ';'),
(32, 929762612, 0, '.'),
(33, 801317679, 1, '$_GET[];'),
(34, 801317679, 0, 'Request.QueryString;'),
(35, 801317679, 0, 'Request.Form;'),
(36, 55435013, 1, 'TRUE'),
(37, 55435013, 0, 'FALSE'),
(39, 1413193497, 0, 'TRUE'),
(40, 1413193497, 1, 'FALSE'),
(41, 1945566599, 0, '$myVar'),
(42, 1945566599, 1, '$my-Var'),
(43, 1945566599, 0, '$my_Va'),
(44, 1907804491, 1, 'TRUE'),
(45, 1907804491, 0, 'FALSE'),
(46, 148895155, 0, '<comment>…</comment>'),
(47, 148895155, 1, '/*…*/'),
(48, 148895155, 0, ' *..*'),
(49, 148895155, 0, '<!--…-->'),
(50, 1942010527, 1, '$count++;'),
(51, 1942010527, 0, 'count++;'),
(52, 1942010527, 0, '$count =+1'),
(53, 1942010527, 0, '++count'),
(54, 1660146694, 0, 'connect_mysql(\"localhost\");'),
(55, 1660146694, 0, 'dbopen(\"localhost\");'),
(56, 1660146694, 0, 'mysql_open(\"localhost\");'),
(57, 1660146694, 1, 'mysql_connect(\"localhost\");'),
(58, 457705500, 0, 'new_function myFunction()'),
(59, 457705500, 0, 'create myFunction()'),
(60, 457705500, 1, 'function myFunction()'),
(61, 1548949984, 1, 'TRUE'),
(62, 1548949984, 0, 'FALSE'),
(63, 1876208772, 1, 'TRUE'),
(64, 1876208772, 0, 'FALSE');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `id` int(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `feedback` text NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` (`id`, `name`, `feedback`, `email`) VALUES
(15, 'Juan Dela Cruz', 'wow!', 'juandc@gmail.com'),
(16, 'Ernesto Andrado', 'Great!', 'nestoandrado@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `question_id` int(15) NOT NULL,
  `question` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`question_id`, `question`) VALUES
(55435013, 'In PHP you can use both single quotes (  ) and double quotes ( \" \" ) for strings:'),
(148895155, 'What is a correct way to add a comment in PHP?  '),
(457705500, 'What is the correct way to create a function in PHP?'),
(801317679, 'How do you get information from a form that is submitted using the \"get\" method?'),
(929762612, 'What is the correct way to end a PHP statement?'),
(1413193497, 'Include files must have the file extension \".inc\"'),
(1442552597, 'PHP server scripts are surrounded by delimiters, which?'),
(1485234833, 'What does PHP stand for?'),
(1548949984, 'PHP allows you to send emails directly from a script'),
(1660146694, 'What is the correct way to connect to a MySQL database?'),
(1876208772, 'PHP can be run on Microsoft Windows IIS(Internet Information Server):'),
(1897737642, 'All variables in PHP start with which symbol?'),
(1907804491, 'In PHP, the die() and exit() functions do the exact same thing.'),
(1942010527, 'What is the correct way to add 1 to the $count variable?'),
(1945566599, 'Which one of these variables has an illegal name?');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedbacks`
--
ALTER TABLE `feedbacks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`question_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `feedbacks`
--
ALTER TABLE `feedbacks`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `question_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1945566600;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
