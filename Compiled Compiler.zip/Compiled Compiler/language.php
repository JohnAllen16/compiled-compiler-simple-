<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/language.css">
	<title>Compiled Compiler</title>
</head>
<body>

	<!------C++/C------->

	<header id="return"class="logo">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php" ></i>home</a></li>
				<li><a href="lang.php" class="active"></i>language</a></li>
				<li><a href="quiz.php"></i>Quiz</a></li>
				<li><a href="about.php"></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>

	<div class="wrapper">
	<div class="container">
	<div class="picture-lang">
	<?php

	if (isset($_GET['picture']))
        {
            $a=$_GET['picture'];
          print "<img src=$a>";
        }

	?>
	</div>
	<div class="picture-lang background">
		<?php

	if (isset($_GET['lang']))
        {
            $a=$_GET['lang'];
            $b=$_GET['description'];
          
          print "<h1>$a</h1>";
          print "<p>$b</p>";
        }

	?>
	
	</div>
	</div>
	<div class="lagayan-tatlo">
	<div class="menu-three">
		<ul>
			<li><a href="#online">Online Compilers</a></li>
			<li><a href="#pc">PC Application Compilers</a></li>
			<li><a href="#Mobile">Android Application Compilers</a></li>
		</ul>
	</div>
	</div>
	</div>

	<div class="wrap" id="online">
		<h1>Online Compiler</h1>
		<div class="contain">
			<div class="card">
				<a href="https://www.programiz.com/java-programming/online-compiler/"><img src="img/c2.jpeg"></a>
				<p>Programiz</p>
			</div>

			<div class="card">
				<a href="https://www.onlinegdb.com/online_java_compiler"><img src="img/GDB.png"></a>
				<p>OnlineGDB</p>
			</div>

			<div class="card">
				<a href="https://www.tutorialspoint.com/compile_java_online.php"><img src="img/c1.png"></a>
				<p>Tutorialspoint</p>
			</div>

			<div class="card">
				<a href="https://www.codechef.com/ide"><img src="img/c3.jpg"></a>
				<p>CodeChef</p>
			</div>

			<div class="card">
				<a href="https://onecompiler.com/cpp"><img src="img/c4.jpg"></a>
				<p>OneCompiler</p>
			</div>

			<div class="card">
				<a href="https://rextester.com/l/cpp_online_compiler_gcc"><img src="img/c5.png"></a>
				<p>Rextester</p>
			</div>
		</div>
	</div>

	<div class="wrap" id="Mobile">
		<h1>Mobile Applications</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.n0n3m4.droidc"><img src="img/c7.png"></a>
				<p>C4droid</p>
				<a href="https://play.google.com/store/apps/details?id=com.n0n3m4.droidc"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.cxxdroid"><img src="img/C10.jpg"></a>
				<p>Cxxdroid</p>
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.cxxdroid"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.cxxdroid"><img src="img/c9.png"></a>
				<p>Mobile C</p>
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.cxxdroid"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.krazeapps.cppprogrammingcompiler"><img src="img/c5.png"></a>
				<p>C/C++ Programming Compiler</p>
				<a href="https://play.google.com/store/apps/details?id=com.krazeapps.cppprogrammingcompiler"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.aide.ui"><img src="img/c8.png"></a>
				<p>AIDE- IDE for Android Java C++</p>
				<a href="https://play.google.com/store/apps/details?id=com.aide.ui"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=name.antonsmirnov.android.cppdroid"><img src="img/c6.jpg"></a>
				<p>CppDroid</p>
				<a href="https://play.google.com/store/apps/details?id=name.antonsmirnov.android.cppdroid"><span class="iconify" data-icon="fa:android" style="color: #333;font-size: 22px;"></span></a>
			</div>
		</div>
	</div>


	<div class="wrap" id="pc">
		<h1>PC Software Compiler</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.embarcadero.com/products/cbuilder#tab-content-0-399&utm_source=SoftwareTestingHelp&utm_medium=Leads%20Acquisition&utm_content=SoftwareTestingHelp-0120-C%2B%2Barticle&utm_campaign=SoftwareTestingHelp-0120-C%2B%2Barticle"><img src="img/c11.png"></a>
				<p>C++ Builder</p>
			</div>

			<div class="card">
				<a href="https://visualstudio.microsoft.com/downloads/"><img src="img/c12.png"></a>
				<p>Microsoft Visual C++</p>
			</div>

			<div class="card">
				<a href="https://www.eclipse.org/downloads/"><img src="img/eclipse.png"></a>
				<p>Eclipse</p>
			</div>

			<div class="card">
				<a href="https://sourceforge.net/projects/orwelldevcpp/"><img src="img/c14.jpg"></a>
				<p>Dev-C++</p>
			</div>

			<div class="card">
				<a href="https://netbeans.org/"><img src="img/net.png"></a>
				<p>Apache NetBeans</p>
			</div>
		</div>
	</div>


<a href="#return" class="return"><i class="fas fa-arrow-up"></i></a>


	<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>
</body>
</html>


