<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<link rel="stylesheet" type="text/css" href="css/about.css">
	<title>Compiled Compiler</title>
</head>
<body>

	<header class="logo" id="return">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php"></i>home</a></li>
				<li><a href="lang.php"></i>language</a></li>
				<li><a href="quiz.php"></i>Quiz</a></li>
				<li><a href="about.php" class="active"></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>


<div class="body">
	<div class="title">
		<h1>About Us</h1>
		<div class="statement">
			<p>Every student has a hard time find the right compiler for thier programming language.This site compiled all online compiler, android and ios applications for a certain programming language, and lastly software for basic programming language that we take in our previous class so that if we pursue this website, we can add more programming languages.we develope a website to showcase a 5 (five) most use compiler.</p>
		</div>
	</div>


	<div class="wrapper">
		 <h2>Meet Our Team</h2>
		<div class="container">
			<div class="card">
				<img src="img/gel.jpg">
				<p>Angelo Ariñavo</p>
			</div>

			<div class="card">
				<img src="img/tev.jpg">
				<p>Steven Caadan</p>
			</div>

			<div class="card">
				<img src="img/je.png">
				<p>Jerrecho Alimoot</p>
			</div>

			<div class="card">
				<img src="image/all.jpg">
				<p>John Allen Felicidario</p>
			</div>

			<div class="card">
				<img src="img/sean.jpg">
				<p>Sean Ian Palacio</p>
			</div>
		</div>
	</div>

</div>

	<a href="#return" class="return"><i class="fas fa-arrow-up"></i></a>

<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div id="return" class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>

</body>
</html>