<?php include 'connection.php'; ?>
<?php session_start(); ?>
<?php 

      //Check to see if score is set_error_handler
	if (!isset($_SESSION['score'])){
	   $_SESSION['score'] = 0;
	}
		
//Check if form was submitted
if($_POST){
	$name = $_POST['name'];
	$number = $_POST['number'];
	$selected_answer = $_POST['answer'];
	$id= $_POST['question_id'];
	$next = $number+1;

	//Get correct answer
	$q = "select * from `answers` where question_id	= $id and correct = 1";
	$result = $conn->query($q) or die($conn->error.__LINE__);
	$row = $result->fetch_assoc();
	$correct_answer=$row['id'];



	//compare answer with result
	if($correct_answer == $selected_answer){
		$_SESSION['score']++;
	}

	if($number == $total){
		$insert = "INSERT INTO scores (name, score) VALUES ('".$name."', '".$_SESSION['score']."')";
		header("Location: final.php?name=".$name);
		exit();
	} else {
	        header("Location: question.php?n=".$next."&name=".$name."&id=".$ids."&score=".$_SESSION['score']);

	}
}

?>
