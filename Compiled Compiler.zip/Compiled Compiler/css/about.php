<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<link rel="stylesheet" type="text/css" href="css/about.css">
	<title>Compiled Compiler</title>
</head>
<body>

	<header id="return"class="logo">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php" ></i>home</a></li>
				<li><a href="#" class="active"></i>language</a></li>
				<li><a href="#"></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>