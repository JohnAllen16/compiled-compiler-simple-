<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<link rel="stylesheet" type="text/css" href="css/lang.css">
	<title>Compiled Compiler</title>
</head>
<body>

	<header class="logo" id="return">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php"></i>home</a></li>
				<li><a href="lang.php" class="active"></i>language</a></li>
				<li><a href="quiz.php"></i>Quiz</a></li>
				<li><a href="about.php"></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>

	<div class="wrap">
	<div id="courses" class="container">

	<div class="title">
		<h1 >Courses</h1>
	</div>
		<div class="grid-comp">
			<div class="card">
				<img src="img/Java-Logo.png">	
				<h3>Java</h3>
				<p>Java is a multi-platform, object-oriented, and network-centric language. It is among the most used programming language. Java is also used as a computing platform. It is considered as one of the fast, secure, and reliable programming languages preferred by most organizations to build their projects.</p>
				<a href="java.php?lang=Java&description=Java is a multi-platform, object-oriented, and network-centric language. It is among the most used programming language. Java is also used as a computing platform. It is considered as one of the fast, secure, and reliable programming languages preferred by most organizations to build their projects.&picture=img/java.png">View</a>
			</div>
			<div class="card">
				<img src="img/c.png">
				<h3>C/C++</h3>
				<p>C/C++ C is a high-level programming language that was developed in the mid-1970s. ... C++, pronounced "C plus plus," is a programming language that was built off the C language. The syntax of C++ is nearly identical to C, but it has object-oriented features, which allow the programmer to create objects within the code.</p>
				<a href='language.php?lang=C/C++&description=C/C++ C is a high-level programming language that was developed in the mid-1970s. ... C++, pronounced "C plus plus," is a programming language that was built off the C language. The syntax of C++ is nearly identical to C, but it has object-oriented features, which allow the programmer to create objects within the code.&picture=img/c.png'>View</a>
			</div>
			<div class="card">
				<img src="img/php.png">
				<h3>PHP</h3>
				<p>PHP is a recursive acronym for "PHP: Hypertext Preprocessor".
					PHP is a server side scripting language that is embedded in HTML. It is used to manage dynamic content, databases, session tracking, even build entire e-commerce sites.
					It is integrated with a number of popular databases, including MySQL, PostgreSQL, Oracle, Sybase, Informix, and Microsoft SQL Server.</p>
				<a href='php.php?lang=PHP&description=PHP is a recursive acronym for "PHP: Hypertext Preprocessor".
					PHP is a server side scripting language that is embedded in HTML. It is used to manage dynamic content, databases, session tracking, even build entire e-commerce sites.
					It is integrated with a number of popular databases, including MySQL, PostgreSQL, Oracle, Sybase, Informix, and Microsoft SQL Server.&picture=img/php.png'>View</a>
			</div>
			<div class="card">
				<img src="img/py.png">		
				<h3>Python</h3>
				<p>Python is a high-level programming language designed to be easy to read and simple to implement. It is open source, which means it is free to use, even for commercial applications. Python can run on Mac, Windows, and Unix systems and has also been ported to Java and .NET virtual machines.</p>
				<a href="python.php?lang=Python&description=Python is a high-level programming language designed to be easy to read and simple to implement. It is open source, which means it is free to use, even for commercial applications. Python can run on Mac, Windows, and Unix systems and has also been ported to Java and .NET virtual machines.&picture=img/py.png">View</a>
			</div>
		</div>
	</div>
	</div>

	<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div id="return" class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>


</body>
</html> 

