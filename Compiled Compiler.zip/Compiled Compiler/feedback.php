<?php include 'connection.php';
?>
<head><link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
</head>
<style>

    *{
    margin: 0;
    padding: 0;
}
*,
*::before,
*::after{
    box-sizing: border-box;
}
.rate {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rate:not(:checked) > input {
    position:absolute;
    top:-9999px;
}
.rate:not(:checked) > label {
    float:right;
    width:1em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
    font-size:30px;
    color:#ccc;
}
.rate:not(:checked) > label:before {
    content: '★ ';
}
.rate > input:checked ~ label {
    color: #ffc700;    
}
.rate:not(:checked) > label:hover,
.rate:not(:checked) > label:hover ~ label {
    color: #deb217;  
}
.rate > input:checked + label:hover,
.rate > input:checked + label:hover ~ label,
.rate > input:checked ~ label:hover,
.rate > input:checked ~ label:hover ~ label,
.rate > label:hover ~ input:checked ~ label {
    color: #c59b08;
}

.container{
    width: 100%;
    display: flex;
    flex-direction: column;
    margin: auto;
}

.form{
    width: 100%;
    align-items: center;
    justify-content: center;
    display: flex;
    flex-direction: column;
}
.rate{
    align-items: center;
    justify-content: center;
}

.form > img{
    width: 100%;
    top: 0;
}

.form .submit{
   float: right;
}

input{
    width: 100%;
    padding: 12px;
    margin: 12px 0 0 0;
    border-radius: 12px;
    color: #2C3531;
    border: 2px solid #2C3531;
    background-color: transparent;
    font-family: 'Special Elite', cursive;
    float: right;
}
.contain{
    padding-bottom: 3em;
}

@media screen and (min-width: 800px){
    .feedback{
        width: 100%;
        height: 200px;
        margin:10px 0;
    }
    .contain{
        width: 100%;
        height: 100vh;
        margin: auto;
    }

    .form > img{
        width: 100%;
        padding-left: 2em;
        padding-right: 2em;
        margin: auto;
    }

    .wrapper-form{
        width: 1000px;
        height: 100vh;
        display: flex;
        flex-direction: row;
        margin: auto;
        border-top: 1px dashed grey;
    }

    .submit{
        transition: 300ms ease-in-out;
    }

    .submit:hover{
        cursor: pointer;
        background-color: #D9B08C;
        color: #fff;
        border: 2px solid #D9B08C;
        transition: 300ms ease-in-out;
    }
}
</style>
<div class="contain">
    <div class="wrapper-form">
    <div class="form first">
        <img src="img/int.gif">
    </div>
<div class="form second">
    <h1>Feedback</h1>
 <form action="" method="POST">
        <input type="text" name="name" placeholder="Your Name" required/>
        <br>
        <input type="email" name="email" placeholder="Your Email" required/>
        <br>
        <input class="feedback" type="text" name="feedback" placeholder="Your Feedback" required/>
        <br>
        <br>
        <input type="submit" name="submit" class="submit">
    </form>
    </div>
    </div>
    </div>
<script>
    var element = document.querySelector("form");
element.addEventListener("submit", function(event) {
  event.preventDefault();
  </script>
        <?php
        
            if(isset($_POST['submit']))
            {
                $name=$_POST['name'];
                $email=$_POST['email'];
                $feedback=$_POST['feedback'];     
                $sql = "INSERT INTO feedbacks (name,email,feedback) VALUES ('$name','$email','$feedback')";
                if (mysqli_query($conn, $sql)) {
                   echo "<script type='text/javascript'>alert('Your feedback has been submitted!');</script>";
                } else {
                   echo "Error: " . $sql . ":-" . mysqli_error($conn);
                }
                mysqli_close($conn);
            }
    ?>