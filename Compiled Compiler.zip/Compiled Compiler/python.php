<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
	<script src="https://kit.fontawesome.com/40f81f3433.js" crossorigin="anonymous"/></script>
	<script src="https://code.iconify.design/2/2.1.2/iconify.min.js"></script>
	<link rel="stylesheet" type="text/css" href="css/language.css">
	<title>Compiled Compiler</title>
</head>
<body>

	<!------Python File------->

	<header id="return"class="logo">
		<a href="#" class="com"><h1>COMcom</h1></a>	
		<input type="checkbox" id="nav-toggle" class="nav-toggle">
		<nav>
			<ul>
				<li><a href="index.php" ></i>home</a></li>
				<li><a href="lang.php" class="active"></i>language</a></li>
				<li><a href="quiz.php"></i>Quiz</a></li>
				<li><a href="about.php" ></i>about</a></li>
			</ul>
		</nav>
		<label for="nav-toggle" class="nav-toggle-label">
			<span></span>
		</label>
	</header>

	<div class="wrapper">
	<div class="container">
	<div class="picture-lang">
	<?php

	if (isset($_GET['picture']))
        {
            $a=$_GET['picture'];
          print "<img src=$a>";
        }

	?>
	</div>
	<div class="picture-lang">
		<?php

	if (isset($_GET['lang']))
        {
            $a=$_GET['lang'];
            $b=$_GET['description'];
          
          print "<h1>$a</h1>";
          print "<p>$b</p>";
        }

	?>
	
	</div>
	</div>
	<div class="lagayan-tatlo">
	<div class="menu-three">
		<ul>
			<li><a href="#online">Online Compilers</a></li>
			<li><a href="#pc">PC Application Compilers</a></li>
			<li><a href="#Mobile">Android Application Compilers</a></li>
		</ul>
	</div>
	</div>
	</div>

	<div class="wrap" id="online">
		<h1>Online Compiler</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.onlinegdb.com/online_c_compiler"><img src="img/c2.jpeg"></a>
				<p>Programiz</p>
			</div>

			<div class="card">
				<a href="https://www.programiz.com/python-programming/online-compiler/"><img src="img/GDB.png"></a>
				<p>OnlineGDB</p>
			</div>

			<div class="card">
				<a href="https://www.tutorialspoint.com/execute_python_online.php"><img src="img/c1.png"></a>
				<p>Tutorialspoint</p>
			</div>

			<div class="card">
				<a href="https://www.codechef.com/ide"><img src="img/c3.jpg"></a>
				<p>CodeChef</p>
			</div>

			<div class="card">
				<a href="https://onecompiler.com/python"><img src="python/p4.jpg"></a>
				<p>OneCompiler</p>
			</div>

			<div class="card">
				<a href="https://www.w3schools.com/python/python_compiler.asp"><img src="python/p5.jpg"></a>
				<p>Python Online Compiler</p>
			</div>
		</div>
	</div>

	<div class="wrap" id="Mobile">
		<h1>Mobile Applications</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.kvassyu.coding.py&hl=en&gl=US"><img src="python/p13.png"></a>
				<p>Coding Python</p>
				<a href="https://play.google.com/store/apps/details?id=com.kvassyu.coding.py&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333; font-size: 22px; "></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.pydroid3&hl=en&gl=US"><img src="python/p11.png"></a>
				<p>Pydroid 3 - IDE for Python 3</p>
				<a href="https://play.google.com/store/apps/details?id=ru.iiec.pydroid3&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333; font-size: 22px; "></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.aknayak.progman&hl=en&gl=US"><img src="python/p14.jpg"></a>
				<p>Progman: Learn to Code for free</p>
				<a href="https://play.google.com/store/apps/details?id=com.aknayak.progman&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333; font-size: 22px; "></span></a>
			</div>

			<div class="card">
				<a href="https://apps.apple.com/us/app/koder-code-editor/id1447489375"><img src="python/p15.jpg"></a>
				<p>Koder Code Editor</p>
				<a href="https://apps.apple.com/us/app/koder-code-editor/id1447489375"><span class="iconify" data-icon="fa:apple" style="color: #333;font-size: 22px;"></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=club.onepercent.python_compiler&hl=en&gl=US"><img src="python/p12.jpg"></a>
				<p>Python Compiler - OnePercent</p>
				<a href="https://play.google.com/store/apps/details?id=club.onepercent.python_compiler&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333; font-size: 22px; "></span></a>
			</div>

			<div class="card">
				<a href="https://play.google.com/store/apps/details?id=com.programiz.learnpython&hl=en&gl=US"><img src="python/p2.jpeg"></a>
				<p>Learn Python: Programiz</p>
				<a href="https://play.google.com/store/apps/details?id=com.programiz.learnpython&hl=en&gl=US"><span class="iconify" data-icon="fa:android" style="color: #333; font-size: 22px; "></span></a>
			</div>
		</div>
	</div>


	<div class="wrap" id="pc">
		<h1>PC Software Compiler</h1>
		<div class="contain" >
			<div class="card">
				<a href="https://www.jetbrains.com/pycharm/"><img src="python/p7.png"></a>
				<p>Pycharm</p>
			</div>

			<div class="card">
				<a href="https://www.sublimetext.com/3"><img src="python/p8.png"></a>
				<p>Sublime Text</p>
			</div>

			<div class="card">
				<a href="https://www.eclipse.org/downloads/"><img src="img/eclipse.png"></a>
				<p>Eclipse</p>
			</div>

			<div class="card">
				<a href="https://code.visualstudio.com/"><img src="img/c12.png"></a>
				<p>Visual Studio Code</p>
			</div>

			<div class="card">
				<a href="https://www.python.org/downloads/"><img src="python/p10.png"></a>
				<p>Python</p>
			</div>
		</div>
	</div>


<a href="#return" class="return"><i class="fas fa-arrow-up"></i></a>


	<footer>
		<div class="footer-con">
			<div class="comcom-title">
				<h1>COMcom</h1>
			</div>

			<div class="state-con box">
				<p>Give some shot</p>
			</div>

			<div class="social-media box">
					<ul>
						<li><a href=""><i class="fab fa-facebook"></i></a></li>
						<li><a href=""><i class="fab fa-twitter"></i></a></li>
						<li><a href=""><i class="fab fa-instagram"></i></a></li>
						<li><a href=""><i class="fab fa-youtube"></i></a></li>
					</ul>
			</div>

			<div class="copyright box">
				<p>© 2022 Limahan Phil. All rights reserve </p>
			</div>
		</div>
	</footer>
</body>
</html>


