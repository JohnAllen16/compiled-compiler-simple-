<?php
include 'header.php';
?>
<style>
*,
*::before,
*::after{
    box-sizing: border-box;
}

html{
    font-family: 'Special Elite', cursive;
}

.container2{
    width: 100%;
    height: 70vh;
    padding-top: 4em;
    padding-left: 1em;
    padding-right: 1em;
    display: flex;
    flex-direction: column;
}

.container2 h2{
    padding-bottom: 1em;
}

form{
    width: 100%;
    text-align: center;
}

@media screen and (min-width: 800px){
    .container2{
        max-width: 900px;
        height: 95vh;
        margin: auto;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        padding-top: 4em;
        padding-bottom: 0;
    }

    .container2 h2{
        font-size: 5rem;
    }

    .container2 p{
        font-size: 1.80rem;
    }

    .container2 a{
        background: #333;
        padding: 1em;
        border-radius: 5px;
        color: #fff;
        transition: 300ms ease-in-out;
    }

    .container2 a:hover{
        padding: 1em;
        background: #fff;
        border: 1px solid #333;
        color: #333;
        transition: 300ms ease-in-out;
    }


}
</style> 
<?php include "connection.php"; ?>
<?php session_start(); ?>
<?php
	$name = $_GET['name'];
	//Create Select Query
	$query="select * from shouts order by time desc limit 100";
	$shouts = mysqli_query($conn,$query);

 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Special+Elite&display=swap" rel="stylesheet">
  </head>
  <body>


      <main>
	<div class="container2">
	     <h2>You are Done!</h2>
	     <p>Congrats! <?php echo $name;?> You have completed the test</p>
	     <p>Final score: <?php echo $_SESSION['score']; ?></p>
	     <a href="question.php?n=1&name=<?php echo $name;?>&id=<?php echo $ids;?>" class="submit">Take Test Again</a>
		 <?php session_destroy(); ?>
	</div>
      </main>  
  </body>
</html>
<?php
include 'footer.php'
?>